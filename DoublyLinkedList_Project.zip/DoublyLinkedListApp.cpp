#include "DoublyLinkedList.h"

int main() {
    DoublyLinkedList<int> list;

    list.insertAtFront(10);
    list.insertAtFront(20);
    list.insertAtEnd(30);
    list.insertAtEnd(40);

    std::cout << "List elements: ";
    list.display();

    std::cout << "Size of the list: " << list.size() << std::endl;

    list.deleteFirst();
    std::cout << "After deleting the first element: ";
    list.display();

    list.deleteLast();
    std::cout << "After deleting the last element: ";
    list.display();

    std::cout << "Size of the list: " << list.size() << std::endl;

    return 0;
}
